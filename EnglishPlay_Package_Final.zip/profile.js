
// profile.js loaded - uses localStorage by default
console.log('profile.js loaded');
