// lesson.js - actual lesson content and interactions
console.log('lesson.js loaded - open the file in editor to customize questions');
