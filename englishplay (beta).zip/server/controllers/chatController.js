const Message = require('../models/Message');
// naive stubs; integrate with auth middleware in production
async function sendMessage(req,res){
  const { to, text } = req.body;
  // simulate saving message
  const m = await Message.create({ from: req.body.from || null, to, text });
  res.json({ ok:true, message: m });
}
async function getConversation(req,res){
  const msgs = await Message.find({ $or:[ {from:req.query.me, to:req.params.friendId}, {from:req.params.friendId, to:req.query.me} ] }).sort({createdAt:1}).limit(200);
  res.json(msgs);
}
module.exports = { sendMessage, getConversation };
