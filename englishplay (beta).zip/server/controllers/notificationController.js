const Notification = require('mongoose').model('Notification') || require('../models/Notification');
async function listNotifications(req,res){ const items = await Notification.find({}).sort({createdAt:-1}).limit(50); res.json(items); }
async function markAsRead(req,res){ await Notification.updateOne({ _id: req.params.id }, { $set: { read: true } }); res.json({ ok:true }); }
module.exports = { listNotifications, markAsRead };
