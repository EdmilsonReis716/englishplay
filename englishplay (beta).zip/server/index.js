// EnglishPlay backend example (Node + Express)
const express = require('express');
const fetch = require('node-fetch');
const cors = require('cors');
const bodyParser = require('body-parser');
const nodemailer = require('nodemailer');
require('dotenv').config();
const app = express();
app.use(cors());
app.use(bodyParser.json());

// Example: mount routes (you need to implement controllers/models as per conversation)
app.use('/api/openai', require('./routes/aiRoutes'));
app.use('/api/chat', require('./routes/chatRoutes'));
app.use('/api/notifications', require('./routes/notificationRoutes'));
app.use('/api/payments', require('./routes/paymentRoutes'));

app.use('/', express.static('../frontend'));

const port = process.env.PORT || 4000;
app.listen(port, ()=> console.log('EnglishPlay backend example running on port', port));
