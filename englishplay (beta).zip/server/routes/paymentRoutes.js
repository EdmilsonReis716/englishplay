const router = require('express').Router();
router.post('/preference', (req,res)=> res.json({ ok:true, mock:true }));
router.post('/webhook', (req,res)=> res.json({ ok:true }));
module.exports = router;
