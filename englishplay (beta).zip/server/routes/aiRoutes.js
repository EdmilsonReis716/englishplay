const router = require('express').Router();
router.post('/', async (req,res)=>{
  // proxy to OpenAI - implement in production
  res.json({ choices: [ { message: { content: "Resposta simulada do Sr. TV." } } ] });
});
module.exports = router;
