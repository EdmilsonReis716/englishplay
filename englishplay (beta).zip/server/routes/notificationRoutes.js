const router = require('express').Router();
const { listNotifications, markAsRead } = require('../controllers/notificationController');
router.get('/', listNotifications);
router.post('/:id/read', markAsRead);
module.exports = router;
