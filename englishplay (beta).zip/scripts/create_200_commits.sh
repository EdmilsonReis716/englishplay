#!/usr/bin/env bash
set -e
if [ ! -d ".git" ]; then
  git init
  git config user.email "you@example.com"
  git config user.name "EnglishPlayBot"
fi
for i in $(seq 1 200); do
  echo "autogen commit $i" >> AUTOGEN.md
  git add AUTOGEN.md
  git commit -m "chore: autogen commit $i" || true
done
echo "done"
