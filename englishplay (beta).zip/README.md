EnglishPlay — package (generated)
- frontend/: static frontend
- server/: backend example
- scripts/: utility scripts (create commits etc.)

To create zip:
zip -r englishplay.zip englishplay
