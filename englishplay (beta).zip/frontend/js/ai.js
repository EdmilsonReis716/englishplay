export function setupAI(){ document.addEventListener('click',(e)=>{ if(e.target && e.target.id==='openAi'){ openAiModal(); } }); }
function openAiModal(){ const modal=document.createElement('div'); modal.className='modal-backdrop';
  modal.innerHTML=`<div class="card" style="max-width:820px"><h3 style="color:var(--yellow)">Sr. TV — Assistente</h3>
  <div id="chatArea" style="height:300px;overflow:auto;background:#050710;padding:8px;border-radius:8px;margin-bottom:8px"></div>
  <div style="display:flex;gap:8px"><input id="userMsg" placeholder="Escreva sua dúvida..." style="flex:1"/><button id="sendMsg" class="btn">Enviar</button><button id="closeAi" class="btn">Fechar</button></div></div>`;
  document.body.appendChild(modal);
  modal.querySelector('#closeAi').addEventListener('click', ()=>modal.remove());
  modal.querySelector('#sendMsg').addEventListener('click', async ()=>{ const txt=modal.querySelector('#userMsg').value.trim(); if(!txt) return;
    const area=modal.querySelector('#chatArea'); area.innerHTML+='<div style="color:var(--yellow)">Você: '+txt+'</div>';
    try{ const resp=await fetch('/api/openai', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message:txt})}); const data=await resp.json();
      let assistant=''; if(data && data.choices && data.choices[0] && data.choices[0].message) assistant=data.choices[0].message.content; else if(data && data.choices && data.choices[0] && data.choices[0].text) assistant=data.choices[0].text; else assistant='Sr. TV (simulado): erro';
      area.innerHTML+='<div style="color:#fff">'+assistant+'</div>';
    }catch(err){ area.innerHTML+='<div style="color:#fff">Sr. TV (simulação local): '+(err.message||'erro')+'</div>'; }
  });
}
