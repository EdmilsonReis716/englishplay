import * as Auth from './auth.js';
export function renderApp(logoPath){
  const html = `
    <div class="container card">
      <header style="display:flex;justify-content:space-between;align-items:center">
        <div style="display:flex;gap:10px;align-items:center">
          <img src="${logoPath}" style="height:48px;border-radius:8px"/>
          <div style="color:var(--yellow);font-weight:700">EnglishPlay</div>
        </div>
        <div style="display:flex;gap:10px;align-items:center">
          <input id="searchUsers" placeholder="Pesquisar usuários..." style="padding:8px;border-radius:8px;border:2px solid var(--yellow);background:transparent;color:inherit"/>
          <button id="openAuth" class="btn">Login / Cadastro</button>
          <button id="openAi" class="btn">Sr. TV (IA)</button>
        </div>
      </header>
      <main style="margin-top:14px">
        <section class="card">
          <h1 style="color:var(--yellow)">Aprenda inglês de forma divertida</h1>
          <p class="lead">Aulas, personagens, pontuação e gamificação — 5 aulas grátis.</p>
          <div id="lessonsArea"></div>
        </section>
      </main>
      <footer style="margin-top:12px" class="small">© EnglishPlay — suporte: suporteenglishplay@gmail.com</footer>
    </div>`;
  document.getElementById('app').innerHTML = html;
  document.getElementById('openAuth').addEventListener('click', ()=>Auth.openAuthModal());
}
