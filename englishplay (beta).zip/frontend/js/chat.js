async function sendChatMessage(toUserId, text){
  const token = localStorage.getItem('ep_token');
  if(!token) { alert('Faça login'); return; }
  const resp = await fetch('/api/chat/send', {
    method: 'POST',
    headers: {'Content-Type':'application/json','Authorization':'Bearer ' + token},
    body:JSON.stringify({ to: toUserId, text })
  });
  const data = await resp.json();
  if(!resp.ok) { alert(data.error || 'Erro ao enviar mensagem'); return; }
  return data.message;
}
async function loadConversation(friendId){
  const token = localStorage.getItem('ep_token');
  if(!token) { alert('Faça login'); return; }
  const resp = await fetch('/api/chat/conversation/' + friendId, {
    headers: { 'Authorization': 'Bearer ' + token }
  });
  const msgs = await resp.json();
  const area = document.getElementById('chatArea');
  area.innerHTML = '';
  msgs.forEach(m=>{
    const el = document.createElement('div');
    el.className = m.from === (localStorage.getItem('ep_user_id')||'') ? 'msg me' : 'msg them';
    el.textContent = m.text;
    area.appendChild(el);
  });
}
window.sendChatMessage = sendChatMessage;
window.loadConversation = loadConversation;
