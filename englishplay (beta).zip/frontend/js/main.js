import * as UI from './ui.js';
import * as Auth from './auth.js';
import * as Lessons from './lessons.js';
import * as Payments from './payments.js';
import * as AI from './ai.js';
import * as Chat from './chat.js';

document.addEventListener('DOMContentLoaded', ()=>{
  UI.renderApp('/frontend/assets/logo.png');
  Lessons.renderLessons();
  Auth.setupAuth();
  Payments.setupPayments();
  AI.setupAI();
});
