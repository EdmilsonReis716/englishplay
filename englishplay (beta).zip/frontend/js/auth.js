import * as Storage from './storage.js';
export function setupAuth(){}
export function openAuthModal(){
  const modal = document.createElement('div'); modal.className='modal-backdrop';
  modal.innerHTML = `<div class="card" style="max-width:820px;display:flex;gap:12px">
    <div style="flex:1"><h3 style="color:var(--yellow)">Entrar / Cadastrar</h3>
    <div style="display:flex;gap:8px;margin-bottom:8px"><button id="showLogin" class="btn">Login</button><button id="showSignup" class="btn">Cadastro</button></div>
    <div id="authForms"></div></div><aside style="width:260px"><img src="/frontend/assets/logo.png" style="width:100%;border-radius:8px"/><p class="small">Logo</p></aside></div>`;
  document.body.appendChild(modal); showSignup(modal);
  modal.querySelector('#showSignup').addEventListener('click', ()=>showSignup(modal));
  modal.querySelector('#showLogin').addEventListener('click', ()=>showLogin(modal));
}
function showSignup(modal){
  const af = modal.querySelector('#authForms');
  af.innerHTML = `<form id="signupForm" style="display:flex;flex-direction:column;gap:8px">
    <input id="signupEmail" placeholder="Email ou telefone" required />
    <input id="signupName" placeholder="Nome (como quer ser chamado)" required />
    <input id="signupUser" placeholder="Nome de usuário (único)" required />
    <input id="signupPass1" type="password" placeholder="Senha" required />
    <input id="signupPass2" type="password" placeholder="Confirmar senha" required />
    <div style="display:flex;gap:8px"><button class="btn" type="submit">Cadastrar e continuar</button><button class="btn" type="button" id="closeModal">Fechar</button></div>
  </form>`;
  modal.querySelector('#closeModal').addEventListener('click', ()=>modal.remove());
  modal.querySelector('#signupForm').addEventListener('submit', (ev)=>{
    ev.preventDefault();
    const email = modal.querySelector('#signupEmail').value.trim();
    const name = modal.querySelector('#signupName').value.trim();
    const user = modal.querySelector('#signupUser').value.trim();
    const p1 = modal.querySelector('#signupPass1').value;
    const p2 = modal.querySelector('#signupPass2').value;
    if(p1 !== p2){ alert('As senhas não conferem'); return; }
    const users = Storage.getUsers();
    if(users.find(u=>u.username.toLowerCase()===user.toLowerCase())){ alert('Nome de usuário já existe'); return; }
    const newUser = {email,name,username:user,password:p1,score:0,friends:[],streak:0,nameChanges:0};
    users.push(newUser); Storage.setUsers(users); Storage.setCurrent(newUser);
    openQuestionnaireForm(modal);
  });
}
function showLogin(modal){
  const af = modal.querySelector('#authForms');
  af.innerHTML = `<form id="loginForm" style="display:flex;flex-direction:column;gap:8px">
    <input id="loginUser" placeholder="Email ou nome de usuário" required />
    <input id="loginPass" type="password" placeholder="Senha" required />
    <div style="display:flex;gap:8px"><button class="btn" type="submit">Entrar</button><button class="btn" type="button" id="closeModal">Fechar</button></div>
  </form>`;
  modal.querySelector('#closeModal').addEventListener('click', ()=>modal.remove());
  modal.querySelector('#loginForm').addEventListener('submit', (ev)=>{
    ev.preventDefault();
    const user = modal.querySelector('#loginUser').value.trim();
    const pass = modal.querySelector('#loginPass').value;
    const u = Storage.getUsers().find(x => (x.email===user||x.username===user) && x.password===pass);
    if(!u){ alert('Usuário ou senha inválidos.'); return; }
    Storage.setCurrent(u);
    modal.remove();
    alert('Login realizado como '+u.name);
  });
}
function openQuestionnaireForm(modalParent){
  const qModal = document.createElement('div'); qModal.className='modal-backdrop';
  qModal.innerHTML = `<div class="card" style="max-width:720px"><h3 style="color:var(--yellow)">Questionário de Boas-vindas</h3><form id="questionForm" style="display:flex;flex-direction:column;gap:10px">
    <label>Como você ficou sabendo do EnglishPlay?<input name="source" required /></label>
    <label>Qual sua meta diária de dias consecutivos?<input name="streakGoal" type="number" min="1" max="365" required /></label>
    <label>Para que você quer aprender inglês?<input name="purpose" required /></label>
    <label>Quanto você entende de inglês?<select name="level"><option value="nada">Nada</option><option value="basico">Conversas básicas</option><option value="fluente">Fluente</option></select></label>
    <div style="display:flex;gap:8px"><button class="btn" type="submit">Salvar</button><button class="btn" type="button" id="closeQ">Cancelar</button></div>
  </form></div>`;
  document.body.appendChild(qModal);
  modalParent.remove();
  qModal.querySelector('#closeQ').addEventListener('click', ()=>qModal.remove());
  qModal.querySelector('#questionForm').addEventListener('submit', (ev)=>{
    ev.preventDefault();
    const form = ev.target;
    const answers = { source: form.source.value, streakGoal: form.streakGoal.value, purpose: form.purpose.value, level: form.level.value };
    const u = Storage.getCurrent();
    if(u){ u.questionnaire = answers; Storage.updateCurrent(u); alert('Questionário salvo!'); }
    qModal.remove();
  });
}
