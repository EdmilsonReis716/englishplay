import * as Storage from './storage.js';
import * as Payments from './payments.js';
export function renderLessons(){
  const html = `<div class="lessons-grid" id="lessonsGrid"></div>`;
  document.getElementById('lessonsArea')?.remove?.();
  const main = document.querySelector('main section');
  if(main) main.innerHTML += html;
  const grid = document.getElementById('lessonsGrid');
  for(let i=1;i<=200;i++){
    const btn = document.createElement('button');
    btn.className = 'lesson-btn '+(i<=5?'free':'locked');
    btn.textContent = 'Aula '+i;
    btn.dataset.aula = i;
    btn.addEventListener('click', ()=>onLessonClick(i));
    grid.appendChild(btn);
  }
  updateUnlockedUI();
}
function onLessonClick(aula){
  if(aula>5 && !Storage.isUnlocked()){ Payments.openPaymentModal(); return; }
  const u = Storage.getCurrent();
  if(!u){ alert('Faça login para abrir a aula'); return; }
  const result = confirm('Simular resolução de uma lição da Aula '+aula+' (OK = acerto)');
  if(result){ u.score = (u.score||0) + Math.floor(Math.random()*10 + 5); Storage.updateCurrent(u); alert('Correct! + pontos'); } else { alert('Errado!'); }
}
export function updateUnlockedUI(){ if(Storage.isUnlocked()){ document.querySelectorAll('.lesson-btn.locked').forEach(b=>{ b.classList.remove('locked'); b.classList.add('free'); }); } }
