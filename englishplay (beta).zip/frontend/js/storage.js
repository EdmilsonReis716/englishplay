export function getUsers(){ return JSON.parse(localStorage.getItem('ep_users')||'[]'); }
export function setUsers(v){ localStorage.setItem('ep_users', JSON.stringify(v)); }
export function getCurrent(){ return JSON.parse(localStorage.getItem('ep_current')||'null'); }
export function setCurrent(v){ localStorage.setItem('ep_current', JSON.stringify(v)); }
export function updateCurrent(v){ const users = getUsers(); const i = users.findIndex(u=>u.username===v.username); if(i>=0) users[i]=v; setUsers(users); setCurrent(v); }
export function isUnlocked(){ return JSON.parse(localStorage.getItem('ep_unlocked')||'false'); }
export function setUnlocked(v){ localStorage.setItem('ep_unlocked', JSON.stringify(v)); }
