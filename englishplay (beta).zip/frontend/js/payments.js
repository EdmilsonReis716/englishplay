import * as Storage from './storage.js';
export function setupPayments(){}
export function openPaymentModal(){
  const modal = document.createElement('div'); modal.className='modal-backdrop';
  modal.innerHTML = `<div class="card" style="max-width:720px"><h3 style="color:var(--yellow)">Desbloquear aulas (R$2,00 / mês)</h3>
  <div style="display:flex;gap:12px;flex-wrap:wrap;margin-top:8px">
    <div style="flex:1" class="card">
      <h4 style="color:var(--yellow)">PIX</h4>
      <p id="pixKey">00020126580014BR.GOV.BCB.PIX0136d9b1e552-e431-4d8b-b28e-eca5cddf654252040000530398654040.995802BR5922Edmilson dos Reis Lima6009SAO PAULO621405102mUMXXZDnB63047198</p>
      <div style="display:flex;gap:8px;margin-top:8px"><button id="copyPixBtn" class="btn">Copiar chave PIX</button><button id="genQrBtn" class="btn">Gerar QR</button></div>
      <img id="pixQr" style="margin-top:10px;max-width:220px;display:block" />
    </div>
    <div style="flex:1" class="card"><h4 style="color:var(--yellow)">Cartão</h4><p>Formulário simulado.</p>
      <div style="display:flex;gap:8px;margin-top:8px"><button id="payCardBtn" class="btn">Pagar (simulação)</button><button id="closePay" class="btn">Cancelar</button></div>
    </div>
  </div></div>`;
  document.body.appendChild(modal);
  modal.querySelector('#closePay').addEventListener('click', ()=>modal.remove());
  modal.querySelector('#payCardBtn').addEventListener('click', ()=>{ Storage.setUnlocked(true); modal.remove(); alert('Pagamento simulado: aulas desbloqueadas'); });
  modal.querySelector('#copyPixBtn').addEventListener('click', async ()=>{ await navigator.clipboard.writeText(document.getElementById('pixKey').textContent); alert('Chave PIX copiada'); });
  modal.querySelector('#genQrBtn').addEventListener('click', ()=>{ const q=document.getElementById('pixQr'); q.src='https://api.qrserver.com/v1/create-qr-code/?size=220x220&data='+encodeURIComponent(document.getElementById('pixKey').textContent); });
}
